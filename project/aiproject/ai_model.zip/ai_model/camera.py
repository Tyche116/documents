# coding=utf-8

from __future__ import division

import os
import sys
import time
import datetime
import argparse

import json
import random

from PIL import Image

import cv2
import numpy as np

import torch
from torch.utils.data import DataLoader
from torchvision import datasets
from torch.autograd import Variable

import matplotlib.pyplot as plt
import matplotlib.patches as patches
from matplotlib.ticker import NullLocator
from kafka import KafkaProducer
from models.experimental import attempt_load
from utils.general import (check_img_size, non_max_suppression, apply_classifier, scale_coords, xyxy2xywh, strip_optimizer, set_logging)
from utils.plots import plot_one_box
from utils.torch_utils import select_device, load_classifier, time_synchronized
from utils.datasets import letterbox

DEBUG_MODE=False

INFO=0
WARNING=1
ERROR=2
EVENT=3
debuglevel = EVENT



producer = KafkaProducer(bootstrap_servers='119.3.122.90:9095')

def PRINT(level, *args):
    if level >= debuglevel:
        print(*args)

def randid():
    return "".join(random.sample('0123456789',10))

def ray_tracing(xy, poly):
    x, y = xy

    n = len(poly)

    inside = False
    p2x = 0.0
    p2y = 0.0
    xints = 0.0
    p1x, p1y = poly[0]

    for i in range(n+1):
        p2x,p2y = poly[i % n]
        if y > min(p1y,p2y):
            if y <= max(p1y,p2y):
                if x <= max(p1x,p2x):
                    if p1y != p2y:
                        xints = (y-p1y)*(p2x-p1x)/(p2y-p1y)+p1x

                    if p1x == p2x or x <= xints:
                        inside = not inside

        p1x,p1y = p2x,p2y

    return inside

def compute_iou(rec1, rec2):
    """
    computing IoU
    :param rec1: (y0, x0, y1, x1), which reflects
            (top, left, bottom, right)
    :param rec2: (y0, x0, y1, x1)
    :return: scala value of IoU
    """
    # computing area of each rectangles
    S_rec1 = (rec1[2] - rec1[0]) * (rec1[3] - rec1[1])
    S_rec2 = (rec2[2] - rec2[0]) * (rec2[3] - rec2[1])

    # computing the sum_area
    sum_area = S_rec1 + S_rec2

    # find the each edge of intersect rectangle
    left_line = max(rec1[1], rec2[1])
    right_line = min(rec1[3], rec2[3])
    top_line = max(rec1[0], rec2[0])
    bottom_line = min(rec1[2], rec2[2])

    # judge if there is an intersect
    if left_line >= right_line or top_line >= bottom_line:
        return 0

    intersect = (right_line - left_line) * (bottom_line - top_line)

    return (intersect / (sum_area - intersect))*1.0

class BBox():
    def __init__(self, x1, y1, x2, y2, W, H):
        x = x1
        y = y1
        w = x2-x1
        h = y2-y1

        x = x if x>=0 else 0
        y = y if y>=0 else 0
        w = w if w>=0 else 0
        h = h if h>=0 else 0

        if x+w > W:
            w = W-x

        if y+h > H:
            h = H-y

        self.x1 = x
        self.y1 = y

        self.x2 = x+w
        self.y2 = y+h

        self.coords = [self.x1, self.y1, self.x2, self.y2]
        self.bbox = (self.x1, self.y1, w, h)

        self.w = w
        self.h = h

    def area(self):
        return (self.w*self.h)

    def center(self):
        return ((self.coords[0]+self.coords[2])//2, (self.coords[1]+self.coords[3])//2)

class TrackObj():
    MAXFAILEDTIMES = 10
    trackobjsNO = 0

    def __init__(self, name, frame, bbox, conf, interval):
        self.name = name
        self.curpos = bbox
        self.curconf = conf
        self.interval = interval
        self.trajectories = [(bbox,conf,None)]
        self.states = []
        self.statexy = []
        self.statetimes = []
        self.stockno = -1
        self.state_pre = None

        self.number = TrackObj.trackobjsNO
        TrackObj.trackobjsNO += 1

        self.tracker = cv2.TrackerKCF_create()
        if not self.tracker.init(frame, self.curpos.bbox):
            raise Exception("create tracker failed")

        self.failedtimes = 0
        self.notdetectedtimes = 0

        self.starttime = time.time()

    def pushbox(self, bbox, conf, state):
        self.curpos = bbox
        self.curconf = conf
        self.trajectories.append((bbox,conf,state))

    def reinit(self, frame, bbox, conf, state):
        self.pushbox(bbox, conf, state)

        self.tracker = cv2.TrackerKCF_create()

        if not self.tracker.init(frame, self.curpos.bbox):
            raise Exception("create tracker failed")

        self.failedtimes = 0

    def update(self, frame):
        ok, location = self.tracker.update(frame)

        if not ok:
            self.failedtimes += 1

            if self.failedtimes > TrackObj.MAXFAILEDTIMES:
                return ok, False

            self.pushbox(self.curpos, self.curconf, self.trajectories[-1][2])
        else:
            self.failedtimes = 0

            height,width,_ = frame.shape
            x,y,w,h = (location[0], location[1], location[2], location[3])

            bbox = BBox(x, y, x+w, y+h, width, height)

            self.pushbox(bbox, self.curconf, self.trajectories[-1][2])

        return ok, True

    def currentstate(self):
        return 'coil' if self.trajectories[-1][2]=='coil' else 'idle'

    def selfcheck(self, name, bbox, threshold=0.75):
        iou = compute_iou(self.curpos.coords, bbox.coords)
        return (name == self.name) and (iou>threshold), iou

    def checkstate(self):
        TIMES=11
        MIDDLEIDX=-self.interval*(TIMES+1)//2
        MOSTLEFTIDX=-self.interval*TIMES

        MIN_TRAJETORIES = self.interval*TIMES
        MAX_TRAJETORIES = 10000

        # MIN_TRAJETORIES
        if len(self.trajectories) < MIN_TRAJETORIES:
            return None

        # LAZY check to use future state
        bbox,conf,state = self.trajectories[MIDDLEIDX]

        # check in chance or not begin
        stockno = -1

        for i, stock in enumerate(stocks):
            corner1,corner2,corner3,corner4 = \
                ((bbox.x1,bbox.y1), (bbox.x2,bbox.y1), (bbox.x1,bbox.y2), (bbox.x2,bbox.y2))  

            # if ray_tracing(corner1, stock) or ray_tracing(corner2, stock) or \
            #     ray_tracing(corner3, stock) or ray_tracing(corner4, stock):
            if ray_tracing(bbox.center(), stock):
                stockno = i
                break

        if stockno < 0:
            return None

        if self.stockno != stockno:
            self.stockno = stockno

            states = [(1 if trajetory[2]=='coil' else 0)  for trajetory in self.trajectories[MOSTLEFTIDX:]]
            self.state_next = 'idle' if sum(states) > abs(MIDDLEIDX)*2//3 else 'coil'

            # keep trajectories length <= MAX_TRAJETORIES
            while len(self.trajectories) > MAX_TRAJETORIES:
                self.trajectories.pop(0)
        # check in chance or not end

        if state is None:
            return None

        states = [(1 if trajetory[2]==state else 0)  for trajetory in self.trajectories[MOSTLEFTIDX:]]

        leftsum = abs(MIDDLEIDX)-1-sum(states[:MIDDLEIDX])
        rightsum = sum(states[MIDDLEIDX:])
        rightsum_off = sum(states[MIDDLEIDX-1:-1])

        if rightsum_off != abs(MIDDLEIDX) and rightsum == abs(MIDDLEIDX) and leftsum >= abs(MIDDLEIDX)//2:
            if state != self.state_next:
                return None

            cur_time = time.time()
            end_time = time.localtime(cur_time)
            occur_time = time.localtime(cur_time-30)

            self.state_next = None

            event = 'out_of_stock' if state == 'coil' else 'in_stock'

            PRINT(EVENT, "{}\tat stock_({}, {})".format(event, i,  bbox.center()))

            return {
                'name': event,
                'stock': stockno,
                'count': 25*6, # how long to display
                'xy': bbox.center(),
                'occur_time': time.strftime("%Y-%m-%d %H:%M:%S", occur_time),
                'end_time': time.strftime("%Y-%m-%d %H:%M:%S", end_time)
            }

        return None

def cleanint(x, maxval):
    x = 0 if x < 0 else x

    if x >= maxval:
        x = maxval - 1

    return int(x)

def load_model(device, weights_path, imgsz, half):
    # Load model
    model = attempt_load(weights_path, map_location=device)  # load FP32 model
    imgsz = check_img_size(imgsz, s=model.stride.max())  # check img_size
    if half:
        model.half()  # to FP16

    # Get names and colors
    names = model.module.names if hasattr(model, 'module') else model.names
    #colors = [[random.randint(0, 255) for _ in range(3)] for _ in range(len(names))]

    colors = [
        [35, 65, 163],
        [48, 232, 189],
        [197, 87, 91],
        [185, 199, 194],
        [243, 55, 64],
        [168, 77, 13],
        [158, 87, 232],
        [59, 49, 117]
        ]

    return model, imgsz, names, colors

def detect(model, frame):
    # Padded resize
    input_img = letterbox(frame, new_shape=opt.img_size)[0]/255.

    # Stack
    input_imgs = np.stack([input_img], 0)

    # Convert
    input_imgs = input_imgs[:, :, :, ::-1].transpose(0, 3, 1, 2)  # BGR to RGB, to bsx3x416x416
    input_imgs = np.ascontiguousarray(input_imgs)
    input_imgs = torch.FloatTensor(input_imgs.astype(float))

    # Get detections
    with torch.no_grad():
        t1 = time_synchronized()
        if device.type != 'cpu':
            input_imgs = input_imgs.to(device)
        if half:
            input_imgs = input_imgs.half()
        pred = model(input_imgs, augment=None)[0]

        # Apply NMS
        pred = non_max_suppression(pred, opt.conf_thres, opt.iou_thres, classes=opt.classes, agnostic=opt.agnostic_nms)

        gn = torch.tensor(frame.shape)[[1, 0, 1, 0]]  # normalization gain whwh

        det = pred[0]
        if device.type != 'cpu':
            det = det.cpu()

        if det is not None and len(det):
            # Rescale boxes from img_size to frame size
            det[:, :4] = scale_coords(input_imgs.shape[2:], det[:, :4], frame.shape).round()

            # Print results
            for c in det[:, -1].unique():
                n = (det[:, -1] == c).sum()  # detections per class

        # Print time (inference + NMS)
        if DEBUG_MODE: print('Done. (%.3fs)' % (time_synchronized() - t1))

        return [] if det is None else det.numpy()

def findtrackobj(trackobjs, name, bbox, threshold=0.03):
    maxiou = 0.
    trackobj = None

    for t in trackobjs:
        matched, iou = t.selfcheck(name, bbox, threshold)

        if matched and (trackobj is None or iou > maxiou):
            trackobj = t
            maxiou = iou

    return trackobj

def updatetrackobj(trackobjs, frame, MAXNOTDETECTEDTIMES=3):
    removes = []
    forceinfer = False

    for trackobj in trackobjs:
        ok, found = trackobj.update(frame)

        if not ok:
            forceinfer = True

        '''
        if trackobj.name == 'sweep':
            x1,y1,x2,y2 = trackobj.curpos.coords[0],trackobj.curpos.coords[1],trackobj.curpos.coords[2],trackobj.curpos.coords[3]

            edge = 30

            if x1-edge<0 or x2+edge>width or y1-edge<0 or y1+edge>height:
                if (trackobj.notdetectedtimes > MAXNOTDETECTEDTIMES) or not found:
                    removes.append(trackobj)
        elif (trackobj.notdetectedtimes > MAXNOTDETECTEDTIMES) or not found:
            removes.append(trackobj)
        '''

    return forceinfer, removes

def fakedet(trackobjs):
    det = []
    detstates = []

    for t in trackobjs:
        det.append([*t.curpos.coords, t.curconf, names.index(t.name)])
        detstates.append(t.trajectories[-1][2])

    return det,detstates

def det_getstate(sweepbbox, rawdet):
    for *xyxy, conf, cls in reversed(rawdet):
        if conf >= steel_coil_threshold and names[int(cls)] == 'steel_coil':
            bbox = BBox(xyxy[0], xyxy[1], xyxy[2], xyxy[3], width, height)
            iou = compute_iou(sweepbbox.coords, bbox.coords)

            if iou > 0.:
                return 'coil'

    return 'idle'

def cleandet(rawdet):
    det = []
    detstates = []

    for *xyxy, conf, cls in reversed(rawdet):
        if conf >= sweep_threshold and names[int(cls)] == 'sweep':
            det.append((*xyxy, conf, cls))

            bbox = BBox(xyxy[0], xyxy[1], xyxy[2], xyxy[3], width, height)
            detstate = det_getstate(bbox, rawdet)

            detstates.append(detstate)

    return det,detstates

def main(INFERENCE_INTERVAL=25):
    trackobjs = []

    imgs = []  # Stores image paths
    img_detections = []  # Stores detections for each image index
    framenum = -1
    forceinfer = False
    eventlist = []

    PRINT(INFO, "\nPerforming object detection:")

    prev_time = time.time()

    while True:
        ret, frame = cap.read()

        if not ret:
            if opt.save_video:
                cap.release()
                vid_writer.release()

            break

        framenum += 1

        if framenum < opt.skip:
            continue

        frame = cv2.resize(frame, (width, height))

        for i,stock in enumerate(stocks):
            pts = np.array([stock], np.int32)
            cv2.polylines(frame, [pts], True, (0, i*30, 255), thickness=2)

        doinference = (framenum % INFERENCE_INTERVAL == 0) or forceinfer
        forceinfer = False

        if not doinference:
            forceinfer, removes = updatetrackobj(trackobjs, frame)

            timestr = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(time.time()))

            for t in removes:
                PRINT(INFO, 'remove {}{}, {}'.format(t.name, str(t.number).zfill(6), timestr))
                trackobjs.remove(t)

            det,detstates = fakedet(trackobjs)
        else:
            # PRINT(INFO, "Do Inference...")

            det = detect(model, frame)
            det,detstates = cleandet(det)

            PRINT(INFO, det, detstates)

            for t in trackobjs:
                t.notdetectedtimes += 1

            PRINT(INFO, [t.name for t in trackobjs], [(names[int(cls)],conf) for *xyxy, conf, cls in reversed(det)])

        # only 'sweep' will reach here
        for i, (*xyxy, conf, cls) in enumerate(reversed(det)):
            bbox = BBox(xyxy[0], xyxy[1], xyxy[2], xyxy[3], width, height)

            t = findtrackobj(trackobjs, names[int(cls)], bbox)

            if t is not None:
                #PRINT(INFO, 'found trackobj {}/{}'.format(t.number, len(trackobjs)))

                if doinference:
                    t.notdetectedtimes = 0
                    t.reinit(frame, bbox, conf, detstates[i])
            elif bbox.area() > 30*30:
                assert(names[int(cls)] == 'sweep')

                t = TrackObj(names[int(cls)], frame, bbox, conf, INFERENCE_INTERVAL)
                trackobjs.append(t)

                timestr = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(t.starttime))
                PRINT(INFO, 'new {}{}, {}'.format(t.name, str(t.number).zfill(6), timestr))

        # draw begin
        det = []
        _it_box = 1

        for t in trackobjs:
            assert(names[int(cls)] == 'sweep')

            e = t.checkstate()

            if e:
                eventlist.append(e)

                if warehouse is not None:
                    sendreport(e)

            cls = names.index(t.name)
            conf = t.curconf

            det.append([*t.curpos.coords, t.curconf, names.index(t.name)])

            label = '%s_%s %.2f' % (names[int(cls)], t.currentstate(), conf)
            # plot_one_box(bbox.coords, frame, label=label, color=colors[int(cls)], line_thickness=3)
            xyxy = bbox.coords
            plot_one_box(xyxy, frame, label=None, color=colors[int(cls)], line_thickness=2)
            label_xyxy = [width-120, _it_box*15+40, width-20, (_it_box+1)*15+40]
            plot_one_box(label_xyxy, frame, label=label, color=(255,255,255), line_thickness=1.3, draw_box=False)
            _it_box += 1
        # draw end

        timestr = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(time.time()))

        label = '{}'.format(timestr)

        for e in eventlist:
            if e['count'] > 0:
                e['count'] -= 1

                label += ', ({} at stock_{})'.format(e['name'],e['stock'])

        cv2.putText(frame, label, (30,30), cv2.FONT_HERSHEY_PLAIN, 1, (0,0,255), 2)
        if DEBUG_MODE and framenum%100==0:
            print('frame',framenum,'time:',timestr)
        if opt.save_video:
            if vid_writer is None:
                fourcc = 'mp4v'
                fps = cap.get(cv2.CAP_PROP_FPS)
                w,h = width, height
                vid_writer = cv2.VideoWriter(vid_save_path, cv2.VideoWriter_fourcc(*fourcc), fps, (w, h))
            vid_writer.write(frame)
            continue

        if opt.showVideo:
            cv2.imshow("JIAJIA", frame)

        ch = cv2.waitKey(1) & 0xFF

        if ch == ord(' '):
             ch = cv2.waitKey() & 0xFF

        if ch == ord('q'):
            raise StopIteration

        # PRINT(INFO, framenum, json.dumps(results))

def initvideo(opt, wh):
    target_width, target_height = wh

    cap = cv2.VideoCapture(0 if opt.video is None else opt.video)

    opt.save_video = opt.save_video and opt.video is not None

    if opt.save_video:
        vid_writer, vid_save_path = None, os.path.splitext(opt.video)[0]+'_predict.mp4'

    video_width = cap.get(cv2.CAP_PROP_FRAME_WIDTH)
    video_height = cap.get(cv2.CAP_PROP_FRAME_HEIGHT)

    if video_width > video_height:
        width = target_width
        height = int(video_height*target_width/video_width)
    else:
        height = target_height
        width = target_width = int(video_width*target_height/video_height)

    return cap,video_width,video_height,width,height

def loadstocks(stockfile, width, height):
    warehouse = None
    stocks = []

    if os.path.exists(stockfile):
        with open(stockfile, "r") as f:
            stocks = json.load(f)

    if isinstance(stocks, dict):
        warehouse = stocks
        stocks = [warehouse['zones'][i]["points"] for i in range(0, len(warehouse['zones']))]

    for i, stock in enumerate(stocks):
        for j, xy in enumerate(stock):
            stocks[i][j] = (int(width*xy[0]/video_width), int(height*xy[1]/video_height))

    if opt.video == None:
        opt.video = warehouse["rtsp_url"]

    return warehouse, stocks

def sendreport(e):
    stock = e["stock"]
    alert_type = 1 if e["name"] == 'out_of_stock' else 2

    report = {
        "id": randid(),
        "camera_name": warehouse["camera_name"],
        "camera_no": warehouse["camera_no"],
        "height": video_height,
        "rtsp_url": opt.video,
        "width": video_width,
        "zone_name": warehouse["zones"][stock]["name"],
        "zone_no": warehouse["zones"][stock]["no"],
        "occur_time": e["occur_time"],
        "end_time": e["end_time"],
        "alert_type": alert_type
    }

    producer.send('test', json.dumps(report).encode('utf-8'))

    PRINT(EVENT, report)

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--weights_path", type=str, default="best.pt", help="path to weights file")
    # parser.add_argument("--weights_path", type=str, default="yolov5x.pt", help="path to weights file")
    parser.add_argument('--classes', nargs='+', type=int, help='filter by class: --class 0, or --class 0 2 3')
    parser.add_argument("--conf_thres", type=float, default=0.15, help="object confidence threshold")
    parser.add_argument("--iou_thres", type=float, default=0.07, help="iou thresshold for non-maximum suppression")
    parser.add_argument('--agnostic-nms', action='store_true', help='class-agnostic NMS')
    parser.add_argument("--img_size", type=int, default=640, help="size of each image dimension")
    parser.add_argument('--video', default=None, help='test video')
    parser.add_argument('--showVideo', default=False, help='showVideo')
    parser.add_argument('--save_video', action='store_true', help="save video to 'video'_predict.mp4")
    parser.add_argument('--skip', type=int, default=0, help='skip video frames')

    opt = parser.parse_args()
    PRINT(INFO, opt)

    os.makedirs("output", exist_ok=True)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    half = device.type != 'cpu'  # half precision only supported on CUDA

    model, imgsz, names, colors = load_model(device, opt.weights_path, opt.img_size, half)

    cap,video_width,video_height,width,height = initvideo(opt, (640,480))

    warehouse, stocks = loadstocks("./stocks.json", width, height)
    PRINT(INFO, stocks)

    sweep_threshold = 0.25
    steel_coil_threshold = 0.25

    main(INFERENCE_INTERVAL=10)
