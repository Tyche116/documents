# -*- coding: utf-8 -*-
import sys
import cv2
import time
import numpy as np
import argparse
import json

STOCKS = []
tpPointsChoose = []
drawing = False
tempFlag = False

def draw_ROI(event, x, y, flags, param):
    global point1, tpPointsChoose, pts, drawing, tempFlag

    if ((len(tpPointsChoose) == 0) or not (tempFlag == True and drawing == True)) and event == cv2.EVENT_LBUTTONDOWN:
        tempFlag = True
        drawing = False
        point1 = (x, y)
        tpPointsChoose.append((x, y))  # 用于画点
    if event == cv2.EVENT_MBUTTONDOWN:
        tempFlag = False
        drawing = True
        tpPointsChoose = []

# 主要利用了opencv的鼠标回调函数：
# 1.点击鼠标左键，画出点
# 2.回车，生成闭合多边形，并输出坐标点。
# 3.点击鼠标中键，删除多边形。
# 4.按Q键，退出。

TARGET_WIDTH=640
TARGET_HEIGHT=480

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--video', default=None, help='test video')

    opt = parser.parse_args()
    print(opt)

    cv2.namedWindow('video')
    cv2.setMouseCallback('video', draw_ROI)

    cap = cv2.VideoCapture(opt.video if opt.video is not None else 0)

    video_width = cap.get(cv2.CAP_PROP_FRAME_WIDTH)
    video_height = cap.get(cv2.CAP_PROP_FRAME_HEIGHT)

    if video_width > video_height:
        width = TARGET_WIDTH
        height = int(video_height*TARGET_WIDTH/video_width)
    else:
        height = TARGET_HEIGHT
        width = TARGET_WIDTH = int(video_width*TARGET_HEIGHT/video_height)

    while (True):
        ch = (cv2.waitKey(1) & 0xFF)

        if ch == ord('q'):  # 按q键退出
            break

        ret, frame = cap.read()
        frame = cv2.resize(frame, (width, height))

        # display the resulting frame
        if (tempFlag == True and drawing == False) : # 鼠标点击
            cv2.circle(frame, point1, 5, (0, 255, 0), 2)

            for i in range(len(tpPointsChoose) - 1):
                cv2.line(frame, tpPointsChoose[i], tpPointsChoose[i + 1], (255, 0, 0), 2)

        if ch == 13:
            print(tpPointsChoose)

            tempFlag = True
            drawing = True
            STOCKS.append(tpPointsChoose)
            tpPointsChoose = []

        if (tempFlag == False and drawing == True):  # 鼠标中键
            for i in range(len(tpPointsChoose) - 1):
                cv2.line(frame, tpPointsChoose[i], tpPointsChoose[i + 1], (0, 0, 255), 2)

        for stock in STOCKS:
            pts = np.array([stock], np.int32)
            cv2.polylines(frame, [pts], True, (0, 0, 255), thickness=2)

        cv2.imshow('video', frame)

    for i, stock in enumerate(STOCKS):
        for j, xy in enumerate(stock):
            STOCKS[i][j] = (int(video_width*xy[0]/width), int(video_height*xy[1]/height))

    with open("./stocks.json", "w") as f:
        json_str = json.dumps(STOCKS, indent=4)
        f.write(json_str)

    # when everything done , release the capture
    cap.release()
    cv2.destroyAllWindows()
